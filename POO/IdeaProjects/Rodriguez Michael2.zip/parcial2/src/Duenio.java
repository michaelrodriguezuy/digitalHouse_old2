public class Duenio {
    private String nombre, apellido, CUIL;

    public Duenio(String nombre, String apellido, String CUIL) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.CUIL = CUIL;
    }
}
