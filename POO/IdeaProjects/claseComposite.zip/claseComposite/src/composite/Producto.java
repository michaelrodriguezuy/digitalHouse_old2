package composite;

public interface Producto {
    Double costo();
}
