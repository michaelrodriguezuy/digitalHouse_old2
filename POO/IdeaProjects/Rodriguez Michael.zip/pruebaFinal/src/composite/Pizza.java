package composite;

public interface Pizza {
    Double calcularPrecio();
    String toString();
}
