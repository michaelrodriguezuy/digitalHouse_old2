package composite;

public class Simpe implements Pizza{
    private String nombre, descripcion;
    private Double precioBase;
    private Boolean especial;

    public Simpe(String nombre, String descripcion) {
        this.nombre = nombre;
        this.descripcion = descripcion;
    }

    public Double calcularPrecio() {
        if (this.especial) {
            return this.precioBase * 1.7;
        }
        return this.precioBase;
    }


    @Override
    public String toString() {
        return "Simpe{" +
                "nombre='" + nombre + '\'' +
                ", descripcion='" + descripcion + '\'' +
                ", precioBase=" + precioBase +
                ", especial=" + especial +
                '}';
    }

    public void setPrecioBase(Double precioBase) {
        this.precioBase = precioBase;
    }
    public void setEspecial(Boolean especial) {
        this.especial = especial;
    }
}
