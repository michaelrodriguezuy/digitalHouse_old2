import clases.Pizzeria;
import composite.Combinada;
import composite.Pizza;
import composite.Simpe;
import factory.PizzaFactory;

public class Test {
    public static void main(String[] args) {

        Pizzeria pizzeria = new Pizzeria("La Mas mejor");

        Pizza pizza1 = PizzaFactory.getInstance().crearPizza("Simple","pizza1","ta buenaza");
        Pizza pizza2 = PizzaFactory.getInstance().crearPizza("Simple","pizza2","ta buenaza2");
        Pizza pizza4 = PizzaFactory.getInstance().crearPizza("Simple","pizza4","ta buenaza4");
        Pizza pizza3 = PizzaFactory.getInstance().crearPizza("Combinada","pizza3","ta buenaza3");

        ((Simpe)pizza1).setEspecial(true);
        ((Simpe)pizza1).setPrecioBase(700.00);

        //combinada
        ((Simpe)pizza2).setPrecioBase(850.00);
        ((Simpe)pizza4).setPrecioBase(950.00);

        ((Combinada)pizza3).agregaPizza(pizza2);
        ((Combinada)pizza3).agregaPizza(pizza4);
        ((Combinada)pizza3).calcularPrecio();

        pizzeria.agregaPizza(pizza1);
        pizzeria.agregaPizza(pizza2);
        pizzeria.agregaPizza(pizza3);
        pizzeria.agregaPizza(pizza4);

        //mostar el informe de los cursos
        for (String pizza:pizzeria.mostrarPizzas()){
            System.out.println(pizza);
        }

    }
}