package composite;

public interface Curso {
    Double calcularPrecio();
    String toString();
}
