public class Locomotora {
}
