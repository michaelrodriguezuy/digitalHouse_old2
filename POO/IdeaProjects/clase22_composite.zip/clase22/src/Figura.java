public interface Figura {
    Double area();
}
