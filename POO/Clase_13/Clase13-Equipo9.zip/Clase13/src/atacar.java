public interface atacar {
    public void atacar(Integer ataque);
}
