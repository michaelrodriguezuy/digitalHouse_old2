public class Main {

    SistemaArmas robocop = new RobotLiviano(100);

    ((RobotLiviano) robocop).atacar(20);
}