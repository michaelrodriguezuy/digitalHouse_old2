public interface defender {
    public void defender();
}
