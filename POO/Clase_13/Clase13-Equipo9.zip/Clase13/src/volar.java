public interface volar {
    public void volar();
}
